#ifndef __UiSayNew_H__
#define __UiSayNew_H__

#include "../Elem/WndMessageListBox.h"
#include "../Elem/WndShowAnimate.h"
#include "../Elem/WndScrollBar.h"
#include "../Elem/WndText.h"

struct KUiSayNew;
class KUiMsgSayNew : protected KWndShowAnimate
{
public:
	static KUiMsgSayNew*	OpenWindow(KUiSayNew* pContent);		//�򿪴��ڣ�����Ψһ��һ�������ʵ��
	static KUiMsgSayNew*	GetIfVisible();
	static void			LoadScheme(const char* pScheme);	//������淽��
	static void			CloseWindow(bool bDestroy);		//�رմ���
private:
	KUiMsgSayNew() {}
	~KUiMsgSayNew() {}
	void	Show(KUiSayNew* pContent);
	int		Initialize();								//��ʼ��
	int		WndProc(unsigned int uMsg, unsigned int uParam, int nParam);
	void	OnClickMsg(int nMsg);		
	void	ChangeCurSel(bool bNext);
	virtual void	Breathe();

private:
	static KUiMsgSayNew*	m_pSelf;
	KScrollMessageListBox	m_MsgScrollList;	
	KWndText512			m_ChooseText;
	KWndText512			m_infotext;
	KWndImage			m_ImageNPC;


	//KWndMessageListBox		m_InfoText;	
//	KWndScrollBar			m_InfoScroll;

	bool m_bAutoUp;
	bool m_bAutoDown;
	unsigned int	m_uLastScrollTime;
	
};
#endif // __UiMsgSel_H__