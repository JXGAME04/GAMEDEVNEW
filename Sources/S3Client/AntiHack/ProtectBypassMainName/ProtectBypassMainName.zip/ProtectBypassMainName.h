#ifndef ProtectBypassMainName_H
#define ProtectBypassMainName_H

#define TitleLen 			255

void ProtectBypassMainName();
void ScanProtectBypassMainName();
void ThreadProtectBypassMainName();
char * LowCaseChanger (char MixedCase[TitleLen])
#endif