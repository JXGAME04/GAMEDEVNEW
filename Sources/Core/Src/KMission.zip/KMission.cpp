
#include "KCore.h"
#include "KMission.h"
#include "KPlayer.h"
#ifdef _SERVER

BOOL KMission::Activate()
{
	m_cTimerTaskSet.Activate();
	return TRUE;
}
BOOL	KMission::ExecuteScript(char * ScriptFileName, char * szFunName, int nParam)
{
	if (!ScriptFileName || !ScriptFileName[0] || !szFunName  || !szFunName[0]) return FALSE;
	return ExecuteScript(g_FileName2Id(ScriptFileName), szFunName, nParam);	
}

unsigned long	KMission::AddPlayer(unsigned long ulPlayerIndex, unsigned long ulPlayerID, unsigned char ucPlayerGroup, int ulJoinTime/* = 0*/)
{
	if (ulPlayerIndex >= MAX_PLAYER|| ulPlayerID == 0)
		return 0;
	
	unsigned long i = 0;
	TMissionPlayerInfo * pInfo = m_MissionPlayer.FindFree(i);
	
	if (!i || !pInfo)
		return 0;

	strcpy(pInfo->m_szPlayerName, Player[ulPlayerIndex].m_PlayerName);
	pInfo->m_ulPlayerIndex = ulPlayerIndex;
	pInfo->m_ulPlayerID = ulPlayerID;
	pInfo->m_ucPlayerGroup = ucPlayerGroup;
	memset(pInfo->m_nParam, 0, sizeof(pInfo->m_nParam));
	
	if (!ulJoinTime)
		pInfo->m_ulJoinTime = g_SubWorldSet.GetGameTime();
	else
		pInfo->m_ulJoinTime = ulJoinTime;
	m_MissionPlayer.m_FreeIdx.Remove(i);
	m_MissionPlayer.m_UseIdx.Insert(i);
	m_MissionPlayer.m_ulFreeSize --;
	m_MissionPlayer.SetParam(i, MISSION_PARAM_AVAILABLE, MISSION_AVAILABLE_VALUE);
	return i;
};

BOOL	KMission::RemoveNpc(unsigned long ulNpcIndex, unsigned long ulNpcID)
{
	if (ulNpcIndex >= MAX_NPC)
		return 0;
	TMissionNpcInfo Info;
	Info.m_ulNpcIndex = ulNpcIndex;
	Info.m_ulNpcID = ulNpcID;
	if (m_MissionNpc.Remove(&Info))
	{
		if (Npc[ulNpcIndex].m_RegionIndex >= 0)
		{
			SubWorld[Npc[ulNpcIndex].m_SubWorldIndex].m_Region[Npc[ulNpcIndex].m_RegionIndex].RemoveNpc(ulNpcIndex);
			SubWorld[Npc[ulNpcIndex].m_SubWorldIndex].m_Region[Npc[ulNpcIndex].m_RegionIndex].DecRef(Npc[ulNpcIndex].m_MapX, Npc[ulNpcIndex].m_MapY, obj_npc);
		}
		NpcSet.Remove(ulNpcIndex);
	}
	return TRUE;
};

unsigned long	KMission::AddNpc(unsigned long ulNpcIndex, unsigned long ulNpcID, unsigned char ucNpcGroup, int ulJoinTime/* = 0*/)
{
	if (ulNpcIndex >= MAX_NPC|| ulNpcID == 0)
		return 0;
	
	unsigned long i = 0;
	TMissionNpcInfo * pInfo = m_MissionNpc.FindFree(i);
	
	if (!i || !pInfo)
		return 0;
	pInfo->m_ulNpcIndex = ulNpcIndex;
	pInfo->m_ulNpcID = ulNpcID;
	pInfo->m_ucNpcGroup = ucNpcGroup;
	
	if (!ulJoinTime)
		pInfo->m_ulJoinTime = g_SubWorldSet.GetGameTime();
	else
		pInfo->m_ulJoinTime = ulJoinTime;
	m_MissionNpc.m_FreeIdx.Remove(i);
	m_MissionNpc.m_UseIdx.Insert(i);
	m_MissionNpc.m_ulFreeSize --;
	
	return i;
};

BOOL	KMission::ExecuteScript(DWORD dwScriptId,  char * szFunName, int nParam)
{
	try
	{
		KLuaScript * pScript = (KLuaScript* )g_GetScript(dwScriptId);
		if (pScript)
		{
			KSubWorld * pSubWorld = (KSubWorld*)GetOwner();
			
			if (pSubWorld)
			{
				Lua_PushNumber(pScript->m_LuaState, pSubWorld->m_nIndex);
				pScript->SetGlobalName(SCRIPT_SUBWORLDINDEX);
			}
			
			int nTopIndex = 0;
			
			pScript->SafeCallBegin(&nTopIndex);
			pScript->CallFunction(szFunName,0, "d", nParam);
			pScript->SafeCallEnd(nTopIndex);
		}
		return TRUE;
	}
	catch(...)
	{
		printf("Exception Have Caught When Execute Script[%d]!!!!!\n", dwScriptId);
		g_DebugLog("Exception Have Caught When Execute Script[%d]!!!!!", dwScriptId);
		return FALSE;
	}
	return TRUE;
}



int g_MissionTimerCallBackFun(void * pOwner, char * szScriptFile)
{
	if (!pOwner) return FALSE;
	KMission *pMission = (KMission*)pOwner;
	pMission->ExecuteScript(szScriptFile, "OnTimer", 0);
	if (szScriptFile)
		printf("timer %s\n", szScriptFile);
	return 1;
}

#endif
