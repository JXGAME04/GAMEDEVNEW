
levelReq = 80
moneyReq = 200000

function main(sel)
dofile("script/battles/battlejoin.lua")
gio = tonumber(date("%H"))
phut = tonumber(date("%M"))
if (((gio == 10) or (gio == 12) or (gio == 14) or (gio == 16) or (gio == 18) or (gio == 20) or (gio == 22)) and (phut >= 45)) or (((gio == 11) or (gio == 13) or (gio == 15) or (gio == 17) or (gio == 19) or (gio == 22) or (gio == 23)) and (phut < 59)) then
Say("<color=green>T�ng Kim M� Binh:<color> Ph� b�o danh <color=fire>T�ng Kim ��i Chi�n <color> l� "..moneyReq.." l��ng, ng��i c� ��ng c�p tr�n "..levelReq.." c� th� tham gia",3,"V�o b�n T�ng/vbt","V�o b�n Kim/vbk","Tho�t/no")
else
Say("<color=green>T�ng Kim M� Binh:<color> Ho�t ��ng <color=fire>T�ng Kim ��i Chi�n <color>, di�n ra v�o<color=red> 11 gi�, 13 gi�, 15 gi�, 17 gi�, 19 gi�, 21 gi�, 23 gi� <color> h�ng ng�y, m�i tr�n di�n ra trong 60 ph�t, b�o danh tr��c 10 ph�t, ng��i c� ��ng c�p "..levelReq.." tr� l�n c� th� tham gia",1,"Tho�t/no")
end
end;

function vbt()

if (GetLevel() >= levelReq) then
if (GetCash() >= moneyReq) then
if ((GetGlbMissionV(83)-GetGlbMissionV(84)) < 3) then
Say("<color=green>T�ng Kim M� Binh:<color> Ng��i th�c s� mu�n v�o b�n <color=fire>T�ng <color> chu ?",2,"Ta mu�n v�o b�n T�ng/dvbtdi","Tho�t/no")
else
Talk(1,"no","S� l��ng quan T�ng �ang nhi�u h�n Kim <color=red>3 ng��i, <color> kh�ng th� v�o b�n T�ng")
end
else
Talk(1,"no","Ng��i kh�ng c� �� <color=red>"..moneyReq.." l��ng, <color> kh�ng th� tham gia")
end
else
Talk(1,"no","Ng��i kh�ng �� <color=red>c�p "..levelReq..", <color> kh�ng th� tham gia")
end
end;

function vbk()

if (GetLevel() >= levelReq) then
if (GetCash() >= moneyReq) then
if ((GetGlbMissionV(84)-GetGlbMissionV(83)) < 3) then
Say("<color=green>T�ng Kim M� Binh:<color> Ng��i th�c s� mu�n v�o b�n <color=fireKim <color> chu ?",2,"Ta mu�n v�o b�n Kim/dvbkdi","Tho�t/no")
else
Talk(1,"no","S� l��ng quan Kim �ang nhi�u h�n T�ng <color=red>3 ng��i, <color> kh�ng th� v�o b�n Kim")
end
else
Talk(1,"no","Ng��i kh�ng c� �� <color=red>"..moneyReq.." l��ng, <color> kh�ng th� tham gia")
end
else
Talk(1,"no","Ng��i kh�ng �� <color=red>c�p "..levelReq..", <color> kh�ng th� tham gia")
end
end;

function dvbtdi()
Pay(moneyReq)
SetTask(23,1) -- tong
SetTask(24,0)
SetTask(25,0)
SetTask(26,0)
SetGlbMissionV(83,GetGlbMissionV(83)+1)
LeaveTeam()
toadox = 1640
toadoy = 3153
NewWorld(381,toadox,toadoy) -- tong
SetTask(27,GetCamp())
SetTask(28,GetPK())
SetTask(29,GetRank())
SetTask(30,1)
--SetRank(201)
--AddMagic(356,1)
SetCamp(1)
SetCurCamp(1)
SetPunish(0)
SetFightState(0)
SetPKState(0)
SetCreateTeam(0);
--SetTempRevPos(35, 1689*32, 3069*32);
SetRevPos(40)
SetLogoutRV(1)
end;

function dvbkdi()
SetGlbMissionV(84,GetGlbMissionV(84)+1)
Pay(moneyReq)
SetTask(23,2) -- kim
SetTask(24,0)
SetTask(25,0)
SetTask(26,0)
LeaveTeam()
toadox = 2047
toadoy = 2594
NewWorld(381, toadox, toadoy);
SetTask(27,GetCamp())
SetTask(28,GetPK())
SetTask(29,GetRank())
SetTask(30,1)
--SetRank(202)
--AddMagic(356,1)
SetCamp(2)
SetCurCamp(2)
SetPunish(0)
SetFightState(0)
SetCreateTeam(0);
SetPKState(0)
--SetTempRevPos(35, 1243*32, 3547*32);
SetRevPos(41)
SetLogoutRV(1)
end;

function no()
end