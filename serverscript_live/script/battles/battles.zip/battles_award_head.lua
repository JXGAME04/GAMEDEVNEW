--�ν������ý���
--edit by С�˶��
--2007.12.10
--���˻�ý���
--�������,����ʤ��ƽ battles_award_all_singleplayer(���index,������õĸ����ܻ���,�ν𼶱�[1,����,2�м�,3�߼�])
Include("\\script\\lib\\awardtemplet.lua");
Include("\\script\\vonghoa\\item\\head.lua");
Include("\\script\\baoruongthanbi\\head.lua");
--[DinhHQ]
--[20101216]:event ngu thai ket tinh
Include("\\script\\vng_event\\ngusackettinh\\script\\nskt_SongJin.lua");
--new lunar year 2011
Include("\\script\\vng_event\\LunarYear2011\\mission_award.lua")
--[20110225]: 8/3/2011
Include("\\script\\vng_event\\20110225_8_thang_3\\mission_award.lua")
--IncludeLib("LEAGUE")
--IncludeLib("TIMER")

local tbItem ={szName="Kim B�o R��ng", tbProp={6, 1, 2192, 1, 0, 0}, nCount = 20, nExpiredTime = 20100125};

function battles_award_all_singleplayer(nplayerindex,nplayer_point,ngame_level)
	if ngame_level == 3 then --�߼��ν�
		if nplayer_point >= 3000 then
						--Haint code add vong hoa
			if (VH_ActiveDay() == 1) then
				local nVar = random(1,3)
				AddMaterial(nVar)--add vong hoa event 08/2010
			end
			--ADD Key and box
			if (KeyBox_ActiveDropItem() == 1) then
				for i=1, 5 do--add 2 ruong va 2 key
					local nRandomBoxVar = random(10000, 99999)
					local nRandomKeyVar = random(10000, 99999)
					
					local itemindx = AddItem(6,1,30036,1,0,0)
					ITEM_SetExpiredTime(itemindx, 4320);
					SetSpecItemParam(itemindx, 1, nRandomBoxVar)
					SyncItem(itemindx)
					local itemindx = AddItem(6,1,30037,1,0,0)
					ITEM_SetExpiredTime(itemindx, 4320);
					SetSpecItemParam(itemindx, 1, nRandomKeyVar)
					SyncItem(itemindx)
				end
			end
			--dinhhq: event ngu sac ket tinh - tong kim >=3000 diem	
			if (tb_NSKT_SongJin)then
				tb_NSKT_SongJin:giveAward(3000);
			end
			--dinhhq: new lunar year 2011
			tbVNG_LY2011Mission:SongJinAward(3000)
			--[20110225]: 8/3/2011
			tbVNGWD2011_Mission:SongJinAward(3000)

			local noldplayindex = PlayerIndex
			PlayerIndex = nplayerindex
			battles_award_singleplayer_AddItem(nplayer_point)
			PlayerIndex = noldplayindex
			return
		end -- >= 3000 point
		
		
			--dinhhq: event ngu sac ket tinh - tong kim >=1000 diem
		if(nplayer_point >= 1000) then				
				if (tb_NSKT_SongJin)then
					tb_NSKT_SongJin:giveAward(1000);
				end
				--dinhhq: new lunar year 2011
				tbVNG_LY2011Mission:SongJinAward(1000)				
				--[20110225]: 8/3/2011
				tbVNGWD2011_Mission:SongJinAward(1000)
		end -- >= 1000 point		
	end
end


function battles_award_singleplayer_AddItem(nplayer_point)
	--local nWeekDay = tonumber(GetLocalDate("%w"));
local nHour = tonumber(GetLocalDate("%H"))
	--local sogiay = random(30,60)
	--if (nHour >= 21 and nHour < 23) and GetLevel() >=80 then
	--TM_SetTimer(sogiay * 18,125,1,0);
	--TM_SetTimer(5 * 18,126,10,0);
   -- end
--	if nplayer_point >= 2000 then
	--SetTask(3332,nplayer_point)
	--end
	if (nHour >= 13 and nHour < 14) and (nplayer_point >= 20000) then
   tbAwardTemplet:GiveAwardByList({{szName = "S�t Th� L�nh",tbProp={6,1,4564,1,1,0},nCount=1,},}, "test", 1);
	end
		if (nHour >= 21 and nHour < 23) and (nplayer_point >= 20000) then
   tbAwardTemplet:GiveAwardByList({{szName = "S�t Th� L�nh",tbProp={6,1,4564,1,1,0},nCount=1,},}, "test", 1);
	end
	
		if nplayer_point >= 5000 then

			--tbAwardTemplet:GiveAwardByList({{szName="day cot",tbProp={6,1,4574,1,1,0,0},nCount=30},}, "test", 1);

	end
	end