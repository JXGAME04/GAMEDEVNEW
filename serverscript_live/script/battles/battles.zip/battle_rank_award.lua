
--IncludeLib("LEAGUE")
--IncludeLib("TASKSYS");
Include("\\script\\missions\\basemission\\lib.lua")
Include("\\script\\dailogsys\\dailogsay.lua")
Include("\\script\\lib\\awardtemplet.lua")
Include("\\script\\global\\·��_���.lua")
Include("\\script\\activitysys\\g_activity.lua")
Include("\\script\\activitysys\\playerfunlib.lua")
--IncludeLib("TIMER")


-- ����
function battle_rank_sort_Point(nPlayerIndexA, nPlayerIndexB)
	local nTotalPointA = doFunByPlayer(nPlayerIndexA, BT_GetData, PL_TOTALPOINT)
	local nTotalPointB = doFunByPlayer(nPlayerIndexB, BT_GetData, PL_TOTALPOINT)
	return nTotalPointA > nTotalPointB
end

-- PK���
function battle_rank_sort_PK(nPlayerIndexA, nPlayerIndexB)
	local nTotalPointA = doFunByPlayer(nPlayerIndexA, BT_GetData, PL_KILLPLAYER)
	local nTotalPointB = doFunByPlayer(nPlayerIndexB, BT_GetData, PL_KILLPLAYER)
	return nTotalPointA > nTotalPointB
end

-- ɱNPC��
function battle_rank_sort_NPC(nPlayerIndexA, nPlayerIndexB)
	local nTotalPointA = doFunByPlayer(nPlayerIndexA, BT_GetData, PL_KILLNPC)
	local nTotalPointB = doFunByPlayer(nPlayerIndexB, BT_GetData, PL_KILLNPC)
	return nTotalPointA > nTotalPointB
end

-- ��ն
function battle_rank_sort_SER(nPlayerIndexA, nPlayerIndexB)
	local nTotalPointA = doFunByPlayer(nPlayerIndexA, BT_GetData, PL_MAXSERIESKILL)
	local nTotalPointB = doFunByPlayer(nPlayerIndexB, BT_GetData, PL_MAXSERIESKILL)
	return nTotalPointA > nTotalPointB
end



function battle_rank_activity(nBattleLevel)
	
	local tbCmpFun = 
	{
		battle_rank_sort_Point,
		battle_rank_sort_PK,
		battle_rank_sort_NPC,
		battle_rank_sort_SER
	}
	
	G_ACTIVITY:OnMessage("SongJinRank",nBattleLevel, battle_rank_GetSortPlayer0808, tbCmpFun, {})
end

-- 2011����ջ�����ͻ���
function battle_GiveHuanHuanByIndex()
	local tbItem = {szName="V�ng Hoa Chi�n Th�ng",tbProp={6,1,2824,1,0,0},nExpiredTime=20110530}
	tbAwardTemplet:Give(tbItem, 1, {"EventChienThang042011", "zhanshenghuahuan"})
	AddStatData("jiefangri_songjinchanchuzhanshenghuahuan", 1)
end

-- ��20110421~20110523���ܻ���������
function battle_GiveHuahuan(tbPlayerAll)
	local ndate = tonumber(GetLocalDate("%Y%m%d%H%M"))
	local nStartDate = 201104280000
	local nEndDate = 201105300000
	if ndate < nStartDate or ndate > nEndDate then
		return
	end 
	
	local nCount = 10	-- ����������
	local nNumber = getn(tbPlayerAll)
	local nSplit = 1
	if nNumber > nCount then
		nSplit = (nNumber - mod(nNumber,nCount)) / nCount
	end
	
	for i=1,nNumber,nSplit do
		if nCount == 0 then
			break
		end
		nCount = nCount - 1
		nPlayerIndex = tbPlayerAll[i]
		if nPlayerIndex > 0 then
			CallPlayerFunction(nPlayerIndex, battle_GiveHuanHuanByIndex)
		end
	end
end

function battle_finish_activity(nBattleLevel, tbPlayerAll, tbPlayerWin, tbPlayerLos, nWinLos)
-- ��ʱ���� 2010-06-07
	if (DynamicExecute("\\script\\event\\jiefang_jieri\\201004\\main.lua", "FreedomEvent2010:IsActive1") == 1 and nBattleLevel == 3) then
		for i=1, getn(tbPlayerAll) do
			local nPlayerIndex = tbPlayerAll[i]
			
			if nPlayerIndex ~= nil and nPlayerIndex > 0 then
				DynamicExecute("\\script\\event\\jiefang_jieri\\201004\\soldier\\main.lua", "Soldier2010:SongjinSoldier", nPlayerIndex)
			end
		end
		
	end
	G_ACTIVITY:OnMessage("FinishSongJin",nBattleLevel, tbPlayerAll, tbPlayerWin, tbPlayerLos, nWinLos)
	battle_GiveHuahuan(tbPlayerAll)
	bilActivity_EnBattle_2(nBattleLevel, tbPlayerAll, tbPlayerWin, tbPlayerLos, nWinLos)
end

function bilActivity_EnBattle_2(nBattleLevel, tbPlayerAll, tbPlayerWin, tbPlayerLos, nWinLos)
--Msg2Player("<color=white>11111111111111111");
	local nWeekDay = tonumber(GetLocalDate("%w"));
	local nHour = tonumber(GetLocalDate("%H"))
    local sogiay = random(30,60)
	if (nHour >= 21 and nHour < 23 and nWeekDay ~= 6 and nWeekDay ~= 0 ) then
	--TM_SetTimer(sogiay * 18,125,1,0);
	--TM_SetTimer(5 * 18,126,10,0);
	end
	local a = PlayerIndex
	local b, c, d, e = 0, tonumber(GetLocalDate("%H")), 0, 1773
	local Tdate = floor(FormatTime2Number(GetCurServerTime()+24*60*60)/10000)
			local nWeekDay = tonumber(GetLocalDate("%w"));
	                                                       local nHour = tonumber(GetLocalDate("%H%M"))
	
	for _i = 1, getn(tbPlayerWin) do
		PlayerIndex = tbPlayerWin[_i]
		b = BT_GetData(1)
			SetTask(3332,GetTask(3332)+b)
											if (b >= 20000) and (nHour >=2100 and nHour <2300) then
tbAwardTemplet:GiveAwardByList({{szName="��ng B�o R��ng",tbProp={6,1,4629,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh
tbAwardTemplet:GiveAwardByList({{szName="S�t Th� L�nh",tbProp={6,1,4564,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh
StackExp(20000000)
end
					if (b >= 30000) and (nHour >=2100 and nHour <2300) then
tbAwardTemplet:GiveAwardByList({{szName="Ng�n B�o R��ng",tbProp={6,1,4630,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh
tbAwardTemplet:GiveAwardByList({{szName="Xu",tbProp={4,417,1,1,0},nCount=5,},}, "test", 1);  --manh 3 nhu tinh

--tbAwardTemplet:GiveAwardByList({{szName="S�t Th� L�nh",tbProp={6,1,4564,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh
end
					if (b >= 40000) and (nHour >=2100 and nHour <2300) then
tbAwardTemplet:GiveAwardByList({{szName="Ng�n B�o R��ng",tbProp={6,1,4630,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh
--tbAwardTemplet:GiveAwardByList({{szName="S�t Th� L�nh",tbProp={6,1,4564,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh

end
					if (b >= 10000) and (nHour >=1300 and nHour <1500) then
tbAwardTemplet:GiveAwardByList({{szName="S�t Th� L�nh",tbProp={6,1,4564,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh
--tbAwardTemplet:GiveAwardByList({{szName="M�c B�o R��ng",tbProp={6,1,4628,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh
StackExp(10000000)
end
					if (b >= 10000) and (nHour >=0000 and nHour <0100) then
tbAwardTemplet:GiveAwardByList({{szName="S�t Th� L�nh",tbProp={6,1,4564,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh
StackExp(10000000)
--tbAwardTemplet:GiveAwardByList({{szName="M�c B�o R��ng",tbProp={6,1,4628,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh
end
					if (b >= 20000) and (nHour >=1300 and nHour <1500) then
StackExp(10000000)
end
					if (b >= 30000) and (nHour >=1300 and nHour <1500) then
tbAwardTemplet:GiveAwardByList({{szName="Xu",tbProp={4,417,1,1,0},nCount=5,},}, "test", 1);  --manh 3 nhu tinh
end
					if (b >= 20000) and (nHour >=0000 and nHour <0100) then
StackExp(10000000)
end
					if (b >= 10000) then
tbAwardTemplet:GiveAwardByList({{szName="��o",tbProp={6,1,4699,1,1},nCount=20},}, "test", 1);
end
end		
		for _i = 1, getn(tbPlayerLos) do
			PlayerIndex = tbPlayerLos[_i]
			b = BT_GetData(1)
			SetTask(3332,GetTask(3332)+b)
											if (b >= 20000) and (nHour >=2100 and nHour <2300) then
tbAwardTemplet:GiveAwardByList({{szName="��ng B�o R��ng",tbProp={6,1,4629,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh
tbAwardTemplet:GiveAwardByList({{szName="S�t Th� L�nh",tbProp={6,1,4564,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh
StackExp(20000000)
end
					if (b >= 30000) and (nHour >=2100 and nHour <2300) then
--tbAwardTemplet:GiveAwardByList({{szName="S�t Th� L�nh",tbProp={6,1,4564,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh
tbAwardTemplet:GiveAwardByList({{szName="Xu",tbProp={4,417,1,1,0},nCount=5,},}, "test", 1);  --manh 3 nhu tinh

end
					if (b >= 40000) and (nHour >=2100 and nHour <2300) then
tbAwardTemplet:GiveAwardByList({{szName="Ng�n B�o R��ng",tbProp={6,1,4630,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh
--tbAwardTemplet:GiveAwardByList({{szName="S�t Th� L�nh",tbProp={6,1,4564,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh

end
					if (b >= 10000) and (nHour >=1300 and nHour <1500) then
tbAwardTemplet:GiveAwardByList({{szName="S�t Th� L�nh",tbProp={6,1,4564,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh
--tbAwardTemplet:GiveAwardByList({{szName="M�c B�o R��ng",tbProp={6,1,4628,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh
StackExp(10000000)
end
					if (b >= 10000) and (nHour >=0000 and nHour <0100) then
tbAwardTemplet:GiveAwardByList({{szName="S�t Th� L�nh",tbProp={6,1,4564,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh
StackExp(10000000)
--tbAwardTemplet:GiveAwardByList({{szName="M�c B�o R��ng",tbProp={6,1,4628,1,1},nCount=1,},}, "test", 1);  --manh 3 nhu tinh
end
					if (b >= 20000) and (nHour >=1300 and nHour <1500) then
StackExp(10000000)
end
					if (b >= 30000) and (nHour >=1300 and nHour <1500) then
tbAwardTemplet:GiveAwardByList({{szName="Xu",tbProp={4,417,1,1,0},nCount=5,},}, "test", 1);  --manh 3 nhu tinh
end
					if (b >= 20000) and (nHour >=0000 and nHour <0100) then
StackExp(10000000)
end
					if (b >= 10000) then
tbAwardTemplet:GiveAwardByList({{szName="��o",tbProp={6,1,4699,1,1},nCount=20},}, "test", 1);
end
end
	
	PlayerIndex = a

end




function battle_rank_award0808(nBattleLevel)
	local tbPlayer = {}
	battle_rank_GetSortPlayer0808(tbPlayer, 0, battle_rank_sort_Point)
	for i=1, 20 do
		if tbPlayer[i] and tbPlayer[i] > 0 then
			Msg2MSAll(MISSIONID, format("<color=green>H�ng %d<color>: <color=yellow>%s<color>", i, doFunByPlayer(tbPlayer[i],GetName)))
		end
	end
	for i = 1, 20 do
	local szName = doFunByPlayer(tbPlayer[i],GetName)
		if szName ~= nil and szName ~= "" then
		local nTopPlayerIdx = SearchPlayer(szName);
			if (nTopPlayerIdx > 0) then
				doFunByPlayer(nTopPlayerIdx, AddAward,i)
				doFunByPlayer(nTopPlayerIdx, save_PointRank)
				--- set luu diem
			end
		end
	end;		
end

function save_PointRank()
	local nPointSongJin = BT_GetData(1)
	local nRankPoint = GetTask(5925)
	local nLastWeek = GetTask(5926)
	local nWeekDay = tonumber(GetLocalDate("%W"));
	local nHour = tonumber(GetLocalDate("%H"))

	if (nHour >=21 and nHour <23)	then
	if ( nLastWeek ~= nWeekDay ) then
	SetTask(5925, nPointSongJin)
	SetTask(5926,nWeekDay)
	Msg2Player("C�p nh�t �i�m tu�n m�i - " .. nPointSongJin )
	else
	SetTask(5925, nPointSongJin + nRankPoint)
	Msg2Player("C�p nh�t �i�m - " .. GetTask(5925) )
	end
	Ladder_NewLadder(10200, GetName(), GetTask(5925) , 0);
	print(GetName() .. " - Diem tran nay - " .. nPointSongJin .. " - Diem Tong - " .. GetTask(5925) )
	end
end

Include("\\script\\lib\\objbuffer_head.lua")
_Message =  function (nItemIndex, strBoxName)
	local handle = OB_Create()
	local msg = format("<color=green>Ch�c m�ng <color=yellow>%s<color=green> �� nh�n ���c <color=yellow><%s><color=green> t� <color=yellow><%s><color>" ,GetName(),GetItemName(nItemIndex),strBoxName)
	ObjBuffer:PushObject(handle, msg)
	--RemoteExecute("\\script\\event\\msg2allworld.lua", "broadcast", handle)
	OB_Release(handle)
end
function AddAward(nRank)
	if not nRank then
	return
	end
		local tbThuongTop13h = 
	{
		[1]={
		                   --{szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=50,},
		                 --  {szName="Ti�n th� l�", tbProp={6,1,71,1,0,0,0},nCount=3,},
						  -- 	{szName="M�t n� t��ng qu�n", tbProp={0,11,450,1,0,0},nCount=1,nExpiredTime=2880},
		},
		[2]={
		                   --{szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=30,},
		                   --{szName="Ti�n th� l�", tbProp={6,1,71,1,0,0,0},nCount=2,},   
						   --	{szName="M�t n� t��ng qu�n", tbProp={0,11,450,1,0,0},nCount=1,nExpiredTime=2880},
						   
		},
		[3]={
		                   --{szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=20,},
		                   --{szName="Ti�n th� l�", tbProp={6,1,71,1,0,0,0},nCount=1,},
						   --	{szName="M�t n� t��ng qu�n", tbProp={0,11,450,1,0,0},nCount=1,nExpiredTime=2880},
		},
		[4]={
						  -- 	{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
									            --      {szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=10,},

		},
		[5]={
						 --  	{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
																                 --  {szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=10,},

		},
		[6]={
						  -- 	{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
																               --    {szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=10,},

		},
		[7]={
						  -- 	{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
																                 --  {szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=10,},

		},
		[8]={
						   	--{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
																                --   {szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=10,},

		},
		[9]={
						   --	{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
																                --   {szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=10,},

		},
		[10]={
						   	--{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
																                --   {szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=10,},

		},
	}
	local tbThuongTop21h = 
	{
		[1]={
				           {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=50,},
		                 --  {szName="Ti�n th� l� ��c bi�t", tbProp={6,1,1765,1,0,0,0},nCount=1,},
						   		                  -- {szName="s�t th� l�nh", tbProp={6,1,4564,1,0,0,0},nCount=10,},

				      	-- {szName="M�t n� 1 skill", tbProp={0,11,561,1,0,0},nCount=1,nExpiredTime=1320},
		                 --  {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},
						   		                  -- {szName="thi�t la h�n l� bao", tbProp={6,1,1665,1,0,0,0},nCount=1,},


		},
		[2]={
				           {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=40,},
		                  -- {szName="Ti�n th� l�", tbProp={6,1,71,1,0,0,0},nCount=5,},
						   --	{szName="M�t n� t��ng qu�n", tbProp={0,11,450,1,0,0},nCount=1,nExpiredTime=2880},	  
		                   --{szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},
						 --  	{szName="thi�t la h�n l� bao", tbProp={6,1,1665,1,0,0,0},nCount=1,},
							
		},
		[3]={
				            {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=30,},
		                 --  {szName="Ti�n th� l�", tbProp={6,1,71,1,0,0,0},nCount=5,},
						  -- 	{szName="M�t n� t��ng qu�n", tbProp={0,11,450,1,0,0},nCount=1,nExpiredTime=2880},
									         --          {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},

		},
		[4]={
				            {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=20,},
							--{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
									                 --  {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},

		},
		[5]={
				            {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=10,},
							--{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
									              --     {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},

		},
		[6]={
				            {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=10,},
							--{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
									             --      {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},

		},
		[7]={
				            {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=10,},
							--{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
									              --     {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},

		},
		[8]={
				            {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=10,},
							--{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
									                --   {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},

		},
		[9]={
				            {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=10,},
							--{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
									                  -- {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},

		},
		[10]={
				            {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=10,},
						--	{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
									                --   {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},

		},
		[11]={
				            {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=5,},
						--	{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
									                --   {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},

		},
		[12]={
				            {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=5,},
						--	{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
									                --   {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},

		},
		[13]={
				            {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=5,},
						--	{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
									                --   {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},

		},
		[14]={
				            {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=5,},
						--	{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
									                --   {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},

		},
		[15]={
				            {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=5,},
						--	{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
									                --   {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},

		},
		[16]={
				            {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=5,},
						--	{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
									                --   {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},

		},
		[17]={
				            {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=5,},
						--	{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
									                --   {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},

		},
		[18]={
				            {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=5,},
						--	{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
									                --   {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},

		},
		[19]={
				            {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=5,},
						--	{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
									                --   {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},

		},
		[20]={
				            {szName="Xu", tbProp={4,1503,1,1,0,0,0},nCount=5,},
						--	{szName="M�t n� nguy�n so�i", tbProp={0,11,447,1,0,0},nCount=1,nExpiredTime=2880},
									                --   {szName="Ti�u H�ng Bao", tbProp={6,1,4526,1,0,0,0},nCount=1,},

		},
		
	}
	local tbThuongTopT357 = 
	{
		[1]={
						--   {szName="R��ng HK", tbProp={6,1,4435,1,0,0},nCount=5},
						   -- {szName="mat na", tbProp={0,11,839,1,0,0},nCount=1},
						 --  {szName="M�c b�i", tbProp={6,1,4433,1,0,0},nCount=5},
		},
		[2]={
						  -- {szName="R��ng HK", tbProp={6,1,4435,1,0,0},nCount=5},
		},
		[3]={
						 --  {szName="��ng b�i", tbProp={6,1,4434,1,0,0},nCount=3},
						 --  {szName="M�c b�i", tbProp={6,1,4433,1,0,0},nCount=3},
		},

	}
		local tbThuongTopT4 = 
	{
		[1]={
		                   {szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=50},
						   {szName="B�n ti�u", tbProp={0,10,6,10,0,0},nCount=1,nExpiredTime=2880,},
		},
		[2]={
		                   {szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=30},
		},
		[3]={
		                   {szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=15},
		},
		[4]={
		                   {szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=10},
		},
		[5]={
		                   {szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=10},

		},
		[6]={
		                   {szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=10},

		},
		[7]={
		                   {szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=10},


		},
		[8]={
		                   {szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=10},


		},
		[9]={
		                   {szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=10},


		},
		[10]={
		                   {szName="Xu", tbProp={4,417,1,1,0,0,0},nCount=10},
		},
	}
			local tbThuongTopCN = 
	{
		[1]={
							--{szName="mat na", tbProp={0,11,850,1,0,0},nCount=1},
						--{szName="R��ng HK", tbProp={6,1,4435,1,0,0},nCount=5},
						--   {szName="R��ng HK2", tbProp={6,1,4489,1,0,0},nCount=5},
						  -- {szName="M�c b�i", tbProp={6,1,4433,1,0,0},nCount=5},
		},
		[2]={
						--{szName="R��ng HK", tbProp={6,1,4435,1,0,0},nCount=5},
					--	{szName="mat na", tbProp={0,11,861,1,0,0},nCount=1},
						  -- {szName="M�c b�i", tbProp={6,1,4433,1,0,0},nCount=10},
		},
		[3]={
							--	{szName="R��ng HK", tbProp={6,1,4435,1,0,0},nCount=5},
						 --  {szName="��ng b�i", tbProp={6,1,4433,1,0,0},nCount=5},
		},
	}
	local slog = format("ThuongTop%dTongKim", nRank)
	local nWeekDay = tonumber(GetLocalDate("%w"));
	local nHour = tonumber(GetLocalDate("%H%M"))
	   local tbAward3 = tbThuongTop13h[nRank]	
	   local tbAward4 = tbThuongTop21h[nRank]			   
		if ( nHour >= 1300 and nHour < 1401) then
		--tbAwardTemplet:Give(tbAward3, 1, {slog,slog})
		end
	--	if ( nHour >= 2100 and nHour < 2201) and (nWeekDay == 0 or nWeekDay == 2 or nWeekDay == 3 or nWeekDay == 4 or nWeekDay == 6)  then
			if ( nHour >= 2100 and nHour < 2201) then

		tbAwardTemplet:Give(tbAward4, 1, {slog,slog})
        end
	local nHour = tonumber(GetLocalDate("%H%M"))
                                                                             if nRank == 1 and ( nHour >= 2100 and nHour < 2300) then
                                                                           vongsangtop1()
                                                                             end
                                                                             if nRank == 2 and ( nHour >= 2100 and nHour < 2300) then
                                                                            vongsangtop2()
                                                                             end
                                                                             if nRank == 3 and ( nHour >= 2100 and nHour < 2300) then
                                                                             vongsangtop3()
                                                                             end
																			-- if nRank <= 20 and ( nHour >= 2100 and nHour < 2300) then
																			-- tbAwardTemplet:GiveAwardByList({{szName = "B� Ng� Ma Qu�i",tbProp={6,1,4549,1,1,0},nCount=20,},}, "test", 1);

end
--end

		--if nWeekDay == 3 then
		--local tbAward4 = tbThuongTopT4[nRank]		
		--if (nHour >= 2100 and nHour < 2300) then
		--tbAwardTemplet:Give(tbAward4, 1, {slog,slog})
       -- end
		--end
	--	if nWeekDay == 0 or nWeekDay == 6 then
	--	local tbAward5 = tbThuongTopCN[nRank]		
	--	if (nHour >= 2100 and nHour < 2300) then
	--	tbAwardTemplet:Give(tbAward5, 1, {slog,slog})
       -- end
       -- end	
		--if nHour < 2100 or nHour < 0100 then
		--local tbAward2 = tbThuongTop[nRank]
		--tbAwardTemplet:Give(tbAward2, 1, {slog,slog})
		--end
		--if (nHour >= 1300 and nHour < 1401) then
		--local tbAward1 = tbThuongTop13h[nRank]
		--tbAwardTemplet:Give(tbAward1, 1, {slog,slog})
	--	end
--end
--end

function vongsangtop1()
n_title = 370 --- ID Danh hieu
local nServerTime = GetCurServerTime()+ 72000;
local nDate = FormatTime2Number(nServerTime);
local nDay = floor(mod(nDate,1000000) / 10000);
local nMon = mod(floor(nDate / 1000000) , 100)
local nTime = nMon * 1000000 + nDay * 10000 
Title_AddTitle(n_title, 2, nTime)
Title_ActiveTitle(n_title)
SetTask(1122, n_title);
PlayerFunLib:AddSkillState(1537,1,3,1555200,-1)
PlayerFunLib:AddSkillState(1535,1,3,1555200,-1)

end

function vongsangtop2()
n_title = 371 --- ID Danh hieu
local nServerTime = GetCurServerTime()+ 72000;
local nDate = FormatTime2Number(nServerTime);
local nDay = floor(mod(nDate,1000000) / 10000);
local nMon = mod(floor(nDate / 1000000) , 100)
local nTime = nMon * 1000000 + nDay * 10000 
Title_AddTitle(n_title, 2, nTime)
Title_ActiveTitle(n_title)
SetTask(1122, n_title);
--PlayerFunLib:AddSkillState(1534,1,3,1425600,1)
PlayerFunLib:AddSkillState(1538,1,3,1555200,1)
PlayerFunLib:AddSkillState(1548,1,3,1555200,1)

end

function vongsangtop3()
n_title = 372 --- ID Danh hieu
local nServerTime = GetCurServerTime()+ 72000;
local nDate = FormatTime2Number(nServerTime);
local nDay = floor(mod(nDate,1000000) / 10000);
local nMon = mod(floor(nDate / 1000000) , 100)
local nTime = nMon * 1000000 + nDay * 10000 
Title_AddTitle(n_title, 2, nTime)
Title_ActiveTitle(n_title)
SetTask(1122, n_title);
PlayerFunLib:AddSkillState(1539,1,3,1555200,1)
PlayerFunLib:AddSkillState(1550,1,3,1555200,1)

end


 
function battle_rank_GetSortPlayer0808(tbPlayer, nCamp, pCompare)
	tbPlayer= tbPlayer or {}
	local idx = 0;
	
	for i = 1 , GetMSPlayerCount(MISSIONID, nCamp) do
		idx, pidx = GetNextPlayer(MISSIONID, idx, nCamp)
		if (pidx and  pidx > 0) then
			tinsert(tbPlayer, pidx)
		end
		if (idx <= 0) then 
			break
		end;
	end
	
	sort(tbPlayer, pCompare)
	return tbPlayer
end

function battle_rank_doFun0808(nRank, nSortType, pfun, ...)
	
	local szName,nTotalPoint = BT_GetTopTenInfo(nRank, nSortType);
	
	if szName ~= nil and szName ~= "" then
			local nTopPlayerIdx = SearchPlayer(szName);
			
			if (nTopPlayerIdx > 0) then
				doFunByPlayer(nTopPlayerIdx, pfun,unpack(arg))
			end
		end
end


function logplayer(zFile,szMsg)
  local handle = openfile(zFile,"a")
  write(handle,format("%s\n",szMsg));
  closefile(handle);
 end
