--Author: Fong Ki�u

function main()
	OpenBox()
end