function main()
	dofile("script/missions/citywar_city/chengzhan_map/tuyentrencong.lua")
	NewWorld(221,1587,3068)
end
