function main()
	dofile("script/missions/citywar_city/chengzhan_map/tuyenduoithu.lua")
	NewWorld(221,1332,3061)
end
