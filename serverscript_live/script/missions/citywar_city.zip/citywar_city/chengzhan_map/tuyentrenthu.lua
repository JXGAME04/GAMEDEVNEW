function main()
	dofile("script/missions/citywar_city/chengzhan_map/tuyentrenthu.lua")
	NewWorld(221,1436,2954)
end
