function main()
	dofile("script/missions/citywar_city/chengzhan_map/tuyenduoicong.lua")
	NewWorld(221,1472,3203)
end
